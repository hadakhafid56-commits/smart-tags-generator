import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        ink: "#0E0F13",        // base background — near-black with a blue undertone, not pure #0B0B0B
        panel: "#161821",      // card / panel surface
        panel2: "#1D2030",     // raised surface (inputs, chips)
        line: "#2A2D3C",       // hairline borders
        mist: "#8A8DA3",       // secondary text
        paper: "#F2F1ED",      // primary text on dark
        signal: "#7C6CF0",     // primary accent — violet, distinct from the generic acid-green/terracotta defaults
        signal2: "#3FD6C4",    // secondary accent — teal, used sparingly for "safe/success" states
        gold: "#D9B36C",       // tertiary accent for Pro/premium moments only
        danger: "#E5637A",
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      borderRadius: {
        sm: "6px",
        md: "10px",
        lg: "16px",
      },
    },
  },
  plugins: [],
};
export default config;
