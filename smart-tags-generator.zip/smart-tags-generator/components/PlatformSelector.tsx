"use client";

import { Platform, PLATFORM_RULES } from "@/lib/tag-engine";

const PLATFORMS: Platform[] = ["redbubble", "youtube", "etsy", "amazon-kdp", "general"];

export default function PlatformSelector({
  value,
  onChange,
}: {
  value: Platform;
  onChange: (p: Platform) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="اختر المنصة">
      {PLATFORMS.map((p) => {
        const active = p === value;
        return (
          <button
            key={p}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(p)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors border ${
              active
                ? "bg-signal text-white border-signal"
                : "bg-panel2 text-mist border-line hover:text-paper hover:border-signal/50"
            }`}
          >
            {PLATFORM_RULES[p].label}
          </button>
        );
      })}
    </div>
  );
}
