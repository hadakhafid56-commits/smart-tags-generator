// ---------------------------------------------------------------------------
// Trademark / brand-name filter
// ---------------------------------------------------------------------------
// This is a starting blocklist, not a legal guarantee. Extend it over time —
// store it in the DB (see supabase/schema.sql -> blocked_terms) if you want
// to edit it without redeploying. Matching is case-insensitive and matches
// whole words / word-boundaries so "nike" doesn't also block "unikeys".

export const DEFAULT_BLOCKED_TERMS = [
  // apparel / fashion
  "nike", "adidas", "gucci", "puma", "reebok", "chanel", "louis vuitton",
  "prada", "versace", "balenciaga", "under armour", "supreme", "the north face",
  // entertainment / studios
  "disney", "marvel", "pixar", "warner bros", "dc comics", "netflix",
  "star wars", "harry potter", "pokemon", "pokémon", "nintendo", "hello kitty",
  "sanrio", "hbo", "universal studios",
  // tech / general brands
  "apple", "google", "microsoft", "amazon", "sony", "samsung", "coca-cola",
  "pepsi", "mcdonald's", "starbucks",
  // sports leagues
  "nba", "nfl", "fifa", "premier league",
];

function escapeRegExp(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export interface FilterResult {
  clean: string[];
  removed: string[];
}

/** Removes any tag that contains a blocked brand/trademark term. */
export function filterTrademarks(
  tags: string[],
  blockedTerms: string[] = DEFAULT_BLOCKED_TERMS
): FilterResult {
  const pattern = new RegExp(
    `\\b(${blockedTerms.map(escapeRegExp).join("|")})\\b`,
    "i"
  );
  const clean: string[] = [];
  const removed: string[] = [];
  for (const tag of tags) {
    if (pattern.test(tag)) removed.push(tag);
    else clean.push(tag);
  }
  return { clean, removed };
}

// ---------------------------------------------------------------------------
// Platform profiles — each platform has different tag-count / length rules
// ---------------------------------------------------------------------------

export type Platform = "redbubble" | "youtube" | "etsy" | "amazon-kdp" | "general";

export const PLATFORM_RULES: Record<
  Platform,
  { label: string; maxTags: number; maxTagLength: number; style: "short" | "long-tail" }
> = {
  redbubble: { label: "Redbubble", maxTags: 20, maxTagLength: 20, style: "short" },
  youtube: { label: "YouTube", maxTags: 30, maxTagLength: 30, style: "long-tail" },
  etsy: { label: "Etsy", maxTags: 13, maxTagLength: 20, style: "long-tail" },
  "amazon-kdp": { label: "Amazon KDP", maxTags: 7, maxTagLength: 50, style: "long-tail" },
  general: { label: "General", maxTags: 25, maxTagLength: 25, style: "short" },
};

// ---------------------------------------------------------------------------
// Tag generation
// ---------------------------------------------------------------------------
// NOTE: this is a deterministic, dependency-free generator (prefixes /
// suffixes / synonyms) so the project runs with zero extra API keys. Swap
// the body of `generateTags` for a call to the Anthropic API (see the
// project README) if you want higher-quality, model-generated tags.

const PREFIXES = ["best", "cute", "custom", "vintage", "minimalist", "trendy", "unique", "aesthetic"];
const SUFFIXES = ["gift idea", "design", "art print", "for lovers", "gift for her", "gift for him", "wall decor", "sticker"];

export function generateTags(keyword: string, platform: Platform): string[] {
  const rules = PLATFORM_RULES[platform];
  const base = keyword.trim().toLowerCase();
  if (!base) return [];

  const candidates = new Set<string>();
  candidates.add(base);

  for (const p of PREFIXES) candidates.add(`${p} ${base}`);
  for (const s of SUFFIXES) candidates.add(`${base} ${s}`);
  candidates.add(`${base} lover gift`);
  candidates.add(`funny ${base}`);
  candidates.add(`${base} quote`);
  candidates.add(`${base} pattern`);

  let list = Array.from(candidates)
    .map((t) => t.trim())
    .filter((t) => t.length > 0 && t.length <= rules.maxTagLength);

  if (rules.style === "short") {
    list = list.map((t) => t.replace(/\s+/g, " "));
  }

  return list.slice(0, rules.maxTags);
}
