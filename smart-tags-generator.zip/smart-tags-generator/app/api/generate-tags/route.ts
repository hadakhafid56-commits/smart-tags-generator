import { NextResponse } from "next/server";
import { createClient, createAdmin } from "@/lib/supabase/server";
import { generateTags, filterTrademarks, Platform } from "@/lib/tag-engine";

const FREE_LIMIT = 5;

export async function POST(request: Request) {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً." }, { status: 401 });
  }

  const { keyword, platform } = (await request.json()) as {
    keyword?: string;
    platform?: Platform;
  };

  if (!keyword || !platform) {
    return NextResponse.json({ error: "الكلمة والمنصة مطلوبتان." }, { status: 400 });
  }

  // Admin client bypasses RLS so we can read/update the shared usage counter
  // reliably in one place (RLS still protects this table from direct client access).
  const admin = createAdmin();

  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("plan, usage_count")
    .eq("id", user.id)
    .single();

  if (profileError || !profile) {
    return NextResponse.json({ error: "تعذر العثور على حساب المستخدم." }, { status: 404 });
  }

  const isPro = profile.plan === "pro";
  if (!isPro && profile.usage_count >= FREE_LIMIT) {
    return NextResponse.json(
      { error: "LIMIT_REACHED", message: "لقد استنفدت محاولاتك المجانية." },
      { status: 402 }
    );
  }

  const rawTags = generateTags(keyword, platform);
  const { clean, removed } = filterTrademarks(rawTags);

  if (!isPro) {
    await admin
      .from("profiles")
      .update({ usage_count: profile.usage_count + 1 })
      .eq("id", user.id);
  }

  return NextResponse.json({
    tags: clean,
    removedCount: removed.length,
    usage: {
      plan: profile.plan,
      used: isPro ? profile.usage_count : profile.usage_count + 1,
      limit: isPro ? null : FREE_LIMIT,
    },
  });
}
