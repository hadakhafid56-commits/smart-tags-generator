import type { Metadata } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import ToastProvider from "@/components/ToastProvider";

const display = Space_Grotesk({
  subsets: ["latin"],
  weight: ["500", "700"],
  variable: "--font-display",
});
const body = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
});

export const metadata: Metadata = {
  title: "Smart Tags — مولّد الكلمات المفتاحية الذكي",
  description:
    "مولّد كلمات مفتاحية آمن وخالٍ من العلامات التجارية لمنصات Redbubble وYouTube وEtsy وAmazon KDP.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className={`${display.variable} ${body.variable}`}>
      <body className="font-body antialiased min-h-screen">
        {children}
        <ToastProvider />
      </body>
    </html>
  );
}
