# Print Niche Genie

Build a web-based "POD Keyword & Tag Generator" tool for Print-on-Demand sellers (Etsy, Redbubble, Merch by Amazon, etc.).

CORE FUNCTIONALITY:

- Input: a text field where the user enters a product idea or niche (e.g., "cat design t-shirt", "funny dog mug", "vintage sunset poster")

- Output: 

  1. A list of 13 optimized Etsy-style tags (max 20 characters each, no repeated words across tags, mix of broad and long-tail keywords)

  2. A list of 5-10 SEO-friendly title suggestions combining high-traffic keywords

  3. A short, keyword-rich product description (2-3 sentences) ready to paste into a store listing

  4. A "related niches" section suggesting 3-5 adjacent product ideas based on the input

DESIGN & UX:

- Clean, modern, minimal interface — single input field + a prominent "Generate" button

- Results displayed in organized cards/sections with a "Copy" button next to each tag/title/description for one-click copying

- Mobile-friendly and fast-loading

- Optional: dark/light mode toggle

- Loading state while generating results

TECHNICAL NOTES:

- Since this needs actual keyword intelligence, generate the tags/titles/descriptions using an LLM call (structured JSON output) based on the user's input — don't rely on a static keyword database

- Prompt the LLM internally to think like an Etsy/Redbubble SEO expert: prioritize terms with high search volume and low competition, avoid banned/trademarked terms, include seasonal/trending angles when relevant

- Handle empty input and errors gracefully (e.g., "Please enter a product idea")

- Include a small disclaimer that suggestions should be manually verified against each platform's current tag policies

NICE-TO-HAVE (if feasible):

- History of last 5 searches (saved locally in the session)

- Export results as a .txt or .csv file

- Toggle to generate results specifically for Etsy vs Redbubble vs Amazon Merch (each platform has different tag length/formatting rules)

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://tagsredbubble.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/39b9fd41-18d5-4be5-b193-9b223c974aa3).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
