import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type CreditState = { freeCredits: number; isSubscribed: boolean };

export const UPGRADE_REQUIRED = "UPGRADE_REQUIRED";

export const getMyCredits = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CreditState> => {
    const { data, error } = await context.supabase.rpc("ensure_profile");
    if (error) throw new Error("Couldn't load your credit balance.");
    const row = (Array.isArray(data) ? data[0] : data) as
      | { free_credits?: number | null; is_subscribed?: boolean | null }
      | null;
    return {
      freeCredits: row?.free_credits ?? 0,
      isSubscribed: row?.is_subscribed ?? false,
    };
  });
