export type TrendingGroup = {
  platform: string;
  emoji: string;
  keywords: string[];
};

export type TrendingSnapshot = {
  season: string;
  note: string;
  groups: TrendingGroup[];
};

type SeasonKey = "winter" | "spring" | "summer" | "fall";

const SEASONS: Record<SeasonKey, TrendingSnapshot> = {
  winter: {
    season: "Winter & holiday season",
    note: "Gifting demand peaks — lean into cozy, festive and new-year angles.",
    groups: [
      {
        platform: "Redbubble",
        emoji: "🎨",
        keywords: [
          "retro christmas sweater",
          "cozy cabin winter",
          "funny snowman quote",
          "new year resolution",
          "pastel snowflake pattern",
        ],
      },
      {
        platform: "Etsy",
        emoji: "🛍️",
        keywords: [
          "personalized family pajamas",
          "christmas gift for teacher",
          "winter wedding favor",
          "hygge home decor print",
          "advent countdown design",
        ],
      },
      {
        platform: "Amazon KDP",
        emoji: "📚",
        keywords: [
          "christmas coloring book kids",
          "2026 goal planner",
          "winter word search large print",
          "gratitude journal daily",
          "holiday recipe keeper",
        ],
      },
    ],
  },
  spring: {
    season: "Spring season",
    note: "Fresh, floral and gifting-for-mom searches climb fast.",
    groups: [
      {
        platform: "Redbubble",
        emoji: "🎨",
        keywords: [
          "wildflower cottagecore",
          "funny gardening quote",
          "pastel mushroom art",
          "spring birding illustration",
          "retro easter bunny",
        ],
      },
      {
        platform: "Etsy",
        emoji: "🛍️",
        keywords: [
          "mothers day gift print",
          "spring wedding stationery",
          "plant lover tote design",
          "easter basket name tag",
          "garden party invitation",
        ],
      },
      {
        platform: "Amazon KDP",
        emoji: "📚",
        keywords: [
          "spring coloring book adults",
          "garden planner journal",
          "easter activity book kids",
          "wedding planning notebook",
          "kids nature scavenger hunt",
        ],
      },
    ],
  },
  summer: {
    season: "Summer season",
    note: "Travel, beach and camp keywords dominate buyer searches.",
    groups: [
      {
        platform: "Redbubble",
        emoji: "🎨",
        keywords: [
          "retro surf sunset",
          "funny camping quote",
          "vintage road trip van",
          "tropical fruit pattern",
          "lake day boat vibes",
        ],
      },
      {
        platform: "Etsy",
        emoji: "🛍️",
        keywords: [
          "bachelorette beach shirt",
          "family vacation matching",
          "summer birthday party decor",
          "pool party sign printable",
          "fathers day gift design",
        ],
      },
      {
        platform: "Amazon KDP",
        emoji: "📚",
        keywords: [
          "summer travel journal",
          "kids road trip activity book",
          "beach coloring book adults",
          "camping logbook rv",
          "summer reading log kids",
        ],
      },
    ],
  },
  fall: {
    season: "Fall & Halloween season",
    note: "Halloween, back-to-school and cozy autumn searches are surging now.",
    groups: [
      {
        platform: "Redbubble",
        emoji: "🎨",
        keywords: [
          "pumpkin spice season",
          "vintage halloween ghost",
          "cozy autumn leaves",
          "funny teacher fall quote",
          "spooky cat silhouette",
        ],
      },
      {
        platform: "Etsy",
        emoji: "🛍️",
        keywords: [
          "halloween party printable",
          "back to school teacher gift",
          "thanksgiving table decor",
          "fall wedding welcome sign",
          "personalized trick or treat bag",
        ],
      },
      {
        platform: "Amazon KDP",
        emoji: "📚",
        keywords: [
          "halloween coloring book kids",
          "fall gratitude journal",
          "student academic planner",
          "spooky word search adults",
          "thanksgiving recipe journal",
        ],
      },
    ],
  },
};

export function seasonKeyForMonth(month: number): SeasonKey {
  if (month === 12 || month <= 2) return "winter";
  if (month <= 5) return "spring";
  if (month <= 8) return "summer";
  return "fall";
}

export function getTrendingNiches(date: Date = new Date()): TrendingSnapshot {
  return SEASONS[seasonKeyForMonth(date.getMonth() + 1)];
}
