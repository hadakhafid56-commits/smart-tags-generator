export type Platform = "etsy" | "redbubble" | "merch";

export type PlatformConfig = {
  id: Platform;
  label: string;
  tagCount: number;
  tagMaxChars: number;
  titleMaxChars: number;
  allowRepeatWords: boolean;
  rules: string;
};

export const PLATFORMS: Record<Platform, PlatformConfig> = {
  etsy: {
    id: "etsy",
    label: "Etsy",
    tagCount: 13,
    tagMaxChars: 20,
    titleMaxChars: 140,
    allowRepeatWords: false,
    rules:
      "Etsy: exactly 13 tags, each 20 characters or fewer, lowercase multi-word phrases, no single word repeated across tags, mix broad and long-tail buyer intent phrases. Titles up to 140 characters using separators like | or -.",
  },
  redbubble: {
    id: "redbubble",
    label: "Redbubble",
    tagCount: 14,
    tagMaxChars: 60,
    titleMaxChars: 60,
    allowRepeatWords: true,
    rules:
      "Redbubble: return exactly 14 highly relevant, targeted tags ordered most relevant first, each concise at 1-3 words. Prioritise the highest-search-volume buyer keywords a shopper would actually type; no tag stuffing, no spammy or irrelevant filler, no unrelated trending words, no repeated near-duplicate phrasing. Cover the core subject, 2-3 style/aesthetic angles, the target audience and 1-2 gift/occasion angles. Titles short and descriptive, up to 60 characters.",
  },
  merch: {
    id: "merch",
    label: "Amazon Merch",
    tagCount: 9,
    tagMaxChars: 49,
    titleMaxChars: 60,
    allowRepeatWords: true,
    rules:
      "Amazon Merch on Demand: return exactly 9 tags — the first 2 are short brand/feature bullet tags, the remaining 7 are backend search-term phrases. Every tag is 49 characters or fewer, no competitor brand names, no promotional claims. Titles up to 60 characters, Title Case.",
  },
};

export type SeoResult = {
  input: string;
  platform: Platform;
  tags: string[];
  titles: string[];
  description: string;
  relatedNiches: { name: string; angle: string }[];
};

// Known brand / franchise / character terms that commonly trigger takedowns on
// POD platforms. Not legal advice — a first-pass flag only.
export const RISKY_TERMS: string[] = [
  "disney","mickey mouse","minnie mouse","frozen","elsa","pixar","toy story","star wars","baby yoda","grogu","mandalorian",
  "marvel","spiderman","spider man","iron man","hulk","thor","avengers","captain america","deadpool","x-men","wolverine",
  "dc comics","batman","superman","wonder woman","joker","harley quinn","justice league",
  "nike","just do it","adidas","puma","reebok","supreme","gucci","louis vuitton","chanel","prada","versace","north face",
  "apple","iphone","google","android","microsoft","xbox","playstation","nintendo","mario","zelda","pokemon","pikachu",
  "minecraft","roblox","fortnite","among us","sonic","kirby","among sus",
  "harry potter","hogwarts","gryffindor","lord of the rings","hobbit","game of thrones","stranger things","hellfire club",
  "barbie","hello kitty","sanrio","spongebob","peppa pig","paw patrol","bluey","cocomelon","sesame street","teletubbies",
  "naruto","dragon ball","goku","one piece","luffy","attack on titan","demon slayer","jujutsu kaisen","my hero academia",
  "sailor moon","studio ghibli","totoro","evangelion","death note","hunter x hunter","chainsaw man","gojo","itachi",
  "coca cola","pepsi","starbucks","mcdonalds","red bull","monster energy","jeep","ferrari","lamborghini","tesla","harley davidson",
  "taylor swift","swifties","eras tour","beyonce","drake","bad bunny","bts","blackpink","kanye","travis scott",
  "nfl","nba","mlb","fifa","olympics","super bowl","real madrid","manchester united",
  "netflix","hbo","tiktok","instagram","facebook","snapchat","twitter","youtube","spotify","onlyfans",
  "grinch","dr seuss","winnie the pooh","looney tunes","bugs bunny","scooby doo","rick and morty","simpsons","family guy",
  "squid game","wednesday addams","five nights at freddys","fnaf","hello fresh","lego",
];

export type RiskLevel = "safe" | "risk";

export type TagRisk = {
  level: RiskLevel;
  matches: string[];
};

const WORD_ESCAPE = /[.*+?^${}()|[\]\\]/g;

export function checkTagRisk(tag: string): TagRisk {
  const value = tag.toLowerCase();
  const matches: string[] = [];
  for (const term of RISKY_TERMS) {
    const pattern = new RegExp(`(^|[^a-z0-9])${term.replace(WORD_ESCAPE, "\\$&")}([^a-z0-9]|$)`, "i");
    if (pattern.test(value)) matches.push(term);
  }
  return { level: matches.length ? "risk" : "safe", matches };
}

export function riskyTagCount(tags: string[]): number {
  return tags.filter((t) => checkTagRisk(t).level === "risk").length;
}

export const TRADEMARK_NOTE =
  "Always verify trademarks on USPTO or official databases before publishing on Redbubble.";

export function resultsToText(r: SeoResult): string {
  const p = PLATFORMS[r.platform];
  return [
    `POD Keyword & Tag Generator`,
    `Idea: ${r.input}`,
    `Platform: ${p.label}`,
    ``,
    `TAGS (${r.tags.length})`,
    ...r.tags.map((t) => `- ${t}`),
    ``,
    `TITLES (${r.titles.length})`,
    ...r.titles.map((t) => `- ${t}`),
    ``,
    `DESCRIPTION`,
    r.description,
    ``,
    `RELATED NICHES`,
    ...r.relatedNiches.map((n) => `- ${n.name} (${n.angle})`),
    ``,
    `Verify all suggestions against the platform's current tag and trademark policies.`,
  ].join("\n");
}

export function resultsToCsv(r: SeoResult): string {
  const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
  const rows: string[][] = [["type", "value", "extra"]];
  r.tags.forEach((t) => rows.push(["tag", t, String(t.length)]));
  r.titles.forEach((t) => rows.push(["title", t, String(t.length)]));
  rows.push(["description", r.description, ""]);
  r.relatedNiches.forEach((n) => rows.push(["related_niche", n.name, n.angle]));
  return rows.map((row) => row.map(esc).join(",")).join("\n");
}
