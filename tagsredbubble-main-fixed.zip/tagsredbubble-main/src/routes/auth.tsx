import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";

import { lovable } from "@/integrations/lovable/index";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in to Taggy — POD Keyword & Tag Generator" },
      {
        name: "description",
        content:
          "Sign in or create a free Taggy account to get 5 free print-on-demand tag generations every month.",
      },
      { property: "og:title", content: "Sign in to Taggy — POD Keyword & Tag Generator" },
      {
        property: "og:description",
        content: "Create a free account and get 5 free tag generations for Etsy, Redbubble and Amazon Merch.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => {
      if (data.session) void navigate({ to: "/" });
    });
  }, [navigate]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error: err } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (err) throw err;
        const { data } = await supabase.auth.getSession();
        if (data.session) {
          void navigate({ to: "/" });
        } else {
          setNotice("Check your inbox to confirm your email, then sign in.");
        }
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
        void navigate({ to: "/" });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    setError(null);
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("Google sign-in didn't work. Please try again.");
      setBusy(false);
      return;
    }
    if (result.redirected) return;
    void navigate({ to: "/" });
  }

  return (
    <div className="min-h-screen bg-background text-foreground font-body">
      <div className="mx-auto max-w-[430px] px-5 pt-8 pb-10 space-y-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="size-9 rounded-2xl bg-coral grid place-items-center text-primary-foreground font-round font-extrabold text-lg leading-none">
            T
          </div>
          <div>
            <p className="font-round font-bold leading-none text-[15px]">Taggy</p>
            <p className="text-[10px] text-muted-foreground leading-tight">POD keyword studio</p>
          </div>
        </Link>

        <section className="rounded-[28px] bg-card p-5 shadow-card">
          <h1 className="font-round font-bold text-[22px] leading-tight">
            {mode === "signin" ? "Welcome back" : "Create your free account"}
          </h1>
          <p className="text-[12px] text-muted-foreground mt-1">
            Every new account gets 5 free generations. Upgrade any time for unlimited use.
          </p>

          <button
            type="button"
            onClick={() => void google()}
            disabled={busy}
            className="mt-4 w-full rounded-2xl border border-border bg-background py-3 text-[14px] font-bold transition-transform active:scale-[0.99] disabled:opacity-60"
          >
            Continue with Google
          </button>

          <div className="my-4 flex items-center gap-3 text-[10px] text-muted-foreground">
            <span className="h-px flex-1 bg-border" />
            or
            <span className="h-px flex-1 bg-border" />
          </div>

          <form onSubmit={submit} className="space-y-2">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              aria-label="Email"
              className="w-full rounded-2xl bg-background border border-border px-3.5 py-3 text-[15px] outline-none placeholder:text-muted-foreground"
            />
            <input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password (min. 8 characters)"
              aria-label="Password"
              className="w-full rounded-2xl bg-background border border-border px-3.5 py-3 text-[15px] outline-none placeholder:text-muted-foreground"
            />
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-2xl bg-coral py-3 font-round font-bold text-primary-foreground text-[15px] transition-transform active:scale-[0.99] disabled:opacity-60"
            >
              {busy ? "…" : mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>

          {error && <p className="mt-2 text-[12px] font-medium text-destructive">{error}</p>}
          {notice && <p className="mt-2 text-[12px] font-medium text-muted-foreground">{notice}</p>}

          <button
            type="button"
            onClick={() => {
              setMode(mode === "signin" ? "signup" : "signin");
              setError(null);
              setNotice(null);
            }}
            className="mt-4 w-full text-[12px] text-muted-foreground"
          >
            {mode === "signin"
              ? "New here? Create a free account"
              : "Already have an account? Sign in"}
          </button>
        </section>
      </div>
    </div>
  );
}
