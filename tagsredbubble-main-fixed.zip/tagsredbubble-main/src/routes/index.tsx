import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CopyButton } from "@/components/CopyButton";
import { ThemeToggle } from "@/components/ThemeToggle";
import { generateSeo } from "@/lib/pod-seo.functions";
import {
  PLATFORMS,
  TRADEMARK_NOTE,
  checkTagRisk,
  resultsToCsv,
  resultsToText,
  riskyTagCount,
  type Platform,
  type SeoResult,
} from "@/lib/pod-seo";
import { getTrendingNiches } from "@/lib/trending-niches";
import { AlertTriangle, Copy, Info, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

const FAQ_DATA = [
  {
    question: "How do Redbubble tags work?",
    answer:
      "Redbubble tags are searchable keywords attached to each product. When a shopper types a query, Redbubble matches it to relevant tags and titles. Use buyer-intent phrases (for example, 'funny dog mug' or 'vintage sunset poster') rather than single generic words, and separate each tag with a comma. This Redbubble tag generator suggests targeted tags so your designs surface in more searches.",
  },
  {
    question: "How many tags should I use on Redbubble?",
    answer:
      "Redbubble allows more, but this generator returns exactly 14 focused tags because quality beats quantity: a tight set of relevant, high-intent keywords outperforms long spammy lists. The live tag counter above shows your current count.",
  },
  {
    question: "How to avoid trademark violations on Redbubble?",
    answer:
      "Avoid brand names, character names, franchises, celebrity names, lyrics, logos, and slogans. Our tool flags common trademark risks with a 'Potential Trademark Risk' badge, but this is only a first-pass check, not legal advice. Always verify on USPTO or the platform's official databases before publishing.",
  },
];

const FAQ_SCHEMA = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQ_DATA.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Redbubble Tag Generator & Best Redbubble Keywords Tool | Taggy" },
      {
        name: "description",
        content:
          "Free Redbubble tag generator and best Redbubble keywords tool. Turn any print-on-demand idea into optimized tags, SEO titles, descriptions and related niches for Etsy, Redbubble and Amazon Merch.",
      },
      { property: "og:title", content: "Redbubble Tag Generator & Best Redbubble Keywords Tool | Taggy" },
      {
        property: "og:description",
        content:
          "Generate optimized Redbubble tags, Etsy tags, Amazon Merch keywords, titles, descriptions and niche ideas in one tap.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://tagsredbubles.lovable.app/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://tagsredbubles.lovable.app/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(FAQ_SCHEMA),
      },
    ],
  }),
  component: Index,
});

const CHIP_TONES = ["bg-lilac-soft", "bg-bubble-soft", "bg-sun-soft", "bg-coral-soft"];
const NICHE_EMOJI = ["✨", "☕", "🧢", "🖼️", "🎁"];
const HISTORY_KEY = "taggy-history";

function download(name: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

function Index() {
  const [idea, setIdea] = useState("");
  const [platform, setPlatform] = useState<Platform>("etsy");
  const [history, setHistory] = useState<string[]>([]);
  const [formError, setFormError] = useState<string | null>(null);
  const [result, setResult] = useState<SeoResult | null>(null);
  const [hideRisky, setHideRisky] = useState(false);

  const navigate = useNavigate();
  const trending = getTrendingNiches();
  const run = useServerFn(generateSeo);
  const mutation = useMutation({
    mutationFn: (vars: { idea: string; platform: Platform }) => run({ data: vars }),
    onSuccess: (data) => setResult(data.result),
  });

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem(HISTORY_KEY);
      const parsed: unknown = raw ? JSON.parse(raw) : null;
      if (Array.isArray(parsed)) {
        setHistory(
          parsed
            .filter((v): v is string => typeof v === "string")
            .map((v) => v.slice(0, 120))
            .slice(0, 5),
        );
      }
    } catch {
      /* ignore */
    }
  }, []);

  function pushHistory(value: string) {
    setHistory((prev) => {
      const next = [value, ...prev.filter((p) => p !== value)].slice(0, 5);
      window.sessionStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      return next;
    });
  }

  async function submit(value = idea, plat = platform) {
    const trimmed = value.trim();
    if (!trimmed) {
      setFormError("Please enter a product idea");
      return;
    }
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      toast.error("Please sign in to generate tags.");
      navigate({ to: "/auth" });
      return;
    }
    setFormError(null);
    pushHistory(trimmed);
    mutation.mutate({ idea: trimmed, platform: plat });
  }

  const cfg = PLATFORMS[platform];
  const loading = mutation.isPending;
  const riskyCount = result ? riskyTagCount(result.tags) : 0;
  const visibleTags = result
    ? hideRisky
      ? result.tags.filter((t) => checkTagRisk(t).level === "safe")
      : result.tags
    : [];

  return (
    <div className="min-h-screen bg-background text-foreground font-body">
      <div className="mx-auto max-w-[430px] px-5 pt-5 pb-10 space-y-4">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="size-9 rounded-2xl bg-coral grid place-items-center text-primary-foreground font-round font-extrabold text-lg leading-none">
              T
            </div>
            <div>
              <p className="font-round font-bold leading-none text-[15px]">Taggy</p>
              <p className="text-[10px] text-muted-foreground leading-tight">POD keyword studio</p>
            </div>
          </div>
          <ThemeToggle />
        </header>

        <section className="rounded-[28px] bg-card p-4 shadow-card">
          <h1 className="font-round font-bold text-[22px] leading-tight">
            Turn a product idea into <span className="text-coral">ready-made SEO</span>
          </h1>
          <p className="text-[12px] text-muted-foreground mt-1">
            {cfg.tagCount} tags, 6 titles, a description &amp; niche ideas — in a tap.
          </p>

          <div className="mt-4 flex gap-2">
            {(Object.keys(PLATFORMS) as Platform[]).map((p) => (
              <button
                key={p}
                type="button"
                aria-pressed={platform === p}
                onClick={() => {
                  setPlatform(p);
                  if (idea.trim()) submit(idea, p);
                }}
                className={`rounded-full text-[11px] px-3 py-1.5 transition-colors ${
                  platform === p
                    ? "bg-coral-soft text-coral font-bold"
                    : "bg-background text-muted-foreground font-medium"
                }`}
              >
                {PLATFORMS[p].label}
              </button>
            ))}
          </div>

          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
          >
            <div className="flex-1 rounded-2xl bg-background border border-border px-3.5 py-3 flex items-center gap-2">
              <span className="text-base" aria-hidden>
                🐱
              </span>
              <input
                value={idea}
                onChange={(e) => {
                  setIdea(e.target.value);
                  if (formError) setFormError(null);
                }}
                placeholder="cat design t-shirt"
                aria-label="Product idea or niche"
                className="min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="shrink-0 rounded-2xl bg-coral px-5 py-3 font-round font-bold text-primary-foreground text-[15px] transition-transform active:scale-95 disabled:opacity-60"
            >
              {loading ? "…" : "Generate"}
            </button>
          </form>

          {formError && <p className="mt-2 text-[12px] font-medium text-destructive">{formError}</p>}
          {mutation.isError && !formError && (
            <p className="mt-2 text-[12px] font-medium text-destructive">
              {(mutation.error as Error).message}
            </p>
          )}


          {history.length > 0 && (
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <span className="text-[10px] text-muted-foreground">Recent:</span>
              {history.map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => {
                    setIdea(h);
                    submit(h);
                  }}
                  className="text-[10px] bg-background rounded-full px-2 py-1"
                >
                  {h}
                </button>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-[28px] bg-card p-4 shadow-card">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h2 className="font-round font-bold text-[15px]">🔥 Today&apos;s Trending Niches</h2>
              <p className="text-[11px] text-muted-foreground mt-0.5">{trending.note}</p>
            </div>
            <span className="shrink-0 rounded-full bg-coral-soft text-coral text-[10px] font-bold px-2 py-1">
              {trending.season}
            </span>
          </div>

          <div className="mt-3 grid gap-3">
            {trending.groups.map((group) => (
              <div key={group.platform} className="rounded-2xl bg-background p-3">
                <h3 className="font-round font-semibold text-[13px] flex items-center gap-1.5">
                  <span aria-hidden>{group.emoji}</span>
                  {group.platform}
                </h3>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {group.keywords.map((keyword) => (
                    <button
                      key={keyword}
                      type="button"
                      onClick={() => {
                        setIdea(keyword);
                        submit(keyword);
                      }}
                      title={`Generate tags for "${keyword}"`}
                      className="text-[11px] rounded-full bg-card px-2.5 py-1 font-medium transition-transform active:scale-95"
                    >
                      {keyword}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <p className="mt-3 text-[10px] text-muted-foreground leading-relaxed">
            Simulated seasonal trend picks — tap any keyword to generate a full listing, then verify
            demand on each platform before publishing.
          </p>
        </section>

        {loading && <LoadingCards />}

        {!loading && result && (
          <>
            <section className="rounded-[28px] bg-card p-4">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg" aria-hidden>
                    🏷️
                  </span>
                  <h2 className="font-round font-bold text-[15px]">
                    {PLATFORMS[result.platform].label} tags
                  </h2>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    try {
                      navigator.clipboard.writeText(visibleTags.join(", "));
                    } catch {
                      const el = document.createElement("textarea");
                      el.value = visibleTags.join(", ");
                      document.body.appendChild(el);
                      el.select();
                      document.execCommand("copy");
                      el.remove();
                    }
                    toast("Tags copied to clipboard!");
                  }}
                  className="inline-flex items-start gap-1.5 rounded-full bg-coral-soft px-3 py-1.5 text-[11px] font-bold text-coral text-left leading-tight transition-transform active:scale-95"
                >
                  <Copy size={13} />
                  Copy All Tags (Comma Separated)
                </button>
              </div>
              <div className="mb-3 flex flex-wrap items-center gap-1.5">
                <span
                  className={`inline-block text-[10px] rounded-full px-2 py-0.5 font-medium ${
                    result.tags.length > 15
                      ? "bg-destructive/10 text-destructive"
                      : "bg-sun-soft text-muted-foreground"
                  }`}
                >
                  {result.tags.length > 15
                    ? `${result.tags.length} / 15 — too many tags`
                    : `${result.tags.length} / 15 tags recommended for ${PLATFORMS[result.platform].label}`}
                </span>
                <span className="relative inline-flex group">
                  <button
                    type="button"
                    aria-label={TRADEMARK_NOTE}
                    className="inline-flex items-center gap-1 rounded-full bg-background px-2 py-0.5 text-[10px] font-medium text-muted-foreground"
                  >
                    <Info size={11} />
                    Trademark check
                  </button>
                  <span className="pointer-events-none absolute left-0 top-full z-10 mt-1 hidden w-56 rounded-xl bg-foreground px-2.5 py-2 text-[10px] leading-snug text-background shadow-card group-hover:block group-focus-within:block">
                    {TRADEMARK_NOTE}
                  </span>
                </span>
              </div>

              {riskyCount > 0 && (
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-destructive/10 px-3 py-2">
                  <p className="flex items-start gap-1.5 text-[11px] font-medium leading-snug text-destructive">
                    <AlertTriangle size={13} className="mt-px shrink-0" />
                    {riskyCount} tag{riskyCount > 1 ? "s" : ""} may contain a brand or
                    copyrighted name — review before publishing.
                  </p>
                  <button
                    type="button"
                    onClick={() => setHideRisky((v) => !v)}
                    className="shrink-0 rounded-full bg-card px-2.5 py-1 text-[10px] font-bold text-destructive"
                  >
                    {hideRisky ? "Show flagged" : "Hide flagged"}
                  </button>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {visibleTags.map((tag, i) => {
                  const risk = checkTagRisk(tag);
                  return (
                  <div
                    key={tag}
                    style={{ animationDelay: `${i * 35}ms` }}
                    className={`animate-chip-in flex items-center gap-2 rounded-2xl px-3 py-1.5 text-left ${
                      CHIP_TONES[i % CHIP_TONES.length]
                    }`}
                  >
                    <div className="min-w-0">
                      <span className="block text-[12px] font-medium leading-snug">
                        {tag}
                      </span>
                      <span
                        className={`block text-[10px] leading-tight ${
                          tag.length > PLATFORMS[result.platform].tagMaxChars
                            ? "text-destructive font-bold"
                            : "text-muted-foreground"
                        }`}
                      >
                        {tag.length}/{PLATFORMS[result.platform].tagMaxChars} chars
                      </span>
                      <span
                        title={
                          risk.level === "risk"
                            ? `Possible match: ${risk.matches.join(", ")}. ${TRADEMARK_NOTE}`
                            : "No known brand or franchise term detected."
                        }
                        className={`mt-1 inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[9px] font-bold ${
                          risk.level === "risk"
                            ? "bg-destructive/15 text-destructive"
                            : "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
                        }`}
                      >
                        {risk.level === "risk" ? (
                          <>
                            <AlertTriangle size={9} />
                            Potential Trademark Risk
                          </>
                        ) : (
                          <>
                            <ShieldCheck size={9} />
                            Safe
                          </>
                        )}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          navigator.clipboard.writeText(tag);
                        } catch {
                          const el = document.createElement("textarea");
                          el.value = tag;
                          document.body.appendChild(el);
                          el.select();
                          document.execCommand("copy");
                          el.remove();
                        }
                      }}
                      aria-label={`Copy ${tag}`}
                      className="shrink-0 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-background/80 hover:text-foreground"
                    >
                      <Copy size={12} />
                    </button>
                  </div>
                  );
                })}
              </div>
            </section>

            <section className="rounded-[28px] bg-lilac-soft p-4">
              <div className="flex items-start gap-3 mb-2">
                <span className="text-xl" aria-hidden>
                  💡
                </span>
                <div>
                  <h2 className="font-round font-bold text-[15px] leading-tight">
                    Need premium graphics, fonts, or KDP assets for these tags?
                  </h2>
                  <p className="text-[12px] text-muted-foreground mt-0.5">
                    Get commercial-use designs on Creative Fabrica.
                  </p>
                </div>
              </div>
              <a
                href="https://creativefabrica.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Get professional designs on Creative Fabrica (opens in new tab)"
                className="inline-flex items-center justify-center rounded-2xl bg-coral px-5 py-3 font-round font-bold text-primary-foreground text-[15px] transition-transform active:scale-95"
              >
                Get Professional Designs
              </a>
            </section>

            <section className="rounded-[28px] bg-card p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg" aria-hidden>
                    ✍️
                  </span>
                  <h2 className="font-round font-bold text-[15px]">Title ideas</h2>
                  <span className="text-[10px] bg-sun-soft text-muted-foreground rounded-full px-2 py-0.5">
                    {result.titles.length}
                  </span>
                </div>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      download("taggy-results.txt", resultsToText(result), "text/plain")
                    }
                    className="text-[11px] font-bold text-coral bg-coral-soft rounded-full px-3 py-1.5"
                  >
                    .txt
                  </button>
                  <button
                    type="button"
                    onClick={() => download("taggy-results.csv", resultsToCsv(result), "text/csv")}
                    className="text-[11px] font-bold text-coral bg-coral-soft rounded-full px-3 py-1.5"
                  >
                    .csv
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                {result.titles.map((title) => (
                  <div
                    key={title}
                    className="rounded-2xl bg-background p-3 flex items-center justify-between gap-3"
                  >
                    <p className="text-[13px] leading-snug">{title}</p>
                    <CopyButton value={title} tone="plain" />
                  </div>
                ))}
              </div>
            </section>

            <section className="rounded-[28px] bg-card p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-lg" aria-hidden>
                    📝
                  </span>
                  <h2 className="font-round font-bold text-[15px]">Listing description</h2>
                </div>
                <CopyButton value={result.description} />
              </div>
              <p className="text-[13px] leading-relaxed text-muted-foreground">
                {result.description}
              </p>
            </section>

            <section className="rounded-[28px] bg-lilac-soft p-4">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-lg" aria-hidden>
                  🎲
                </span>
                <h2 className="font-round font-bold text-[15px]">Related niches</h2>
              </div>
              <div className="space-y-2">
                {result.relatedNiches.map((niche, i) => (
                  <button
                    key={niche.name}
                    type="button"
                    onClick={() => {
                      setIdea(niche.name);
                      submit(niche.name);
                    }}
                    className="w-full text-left flex items-center gap-3 rounded-2xl bg-card p-3"
                  >
                    <span className="text-lg" aria-hidden>
                      {NICHE_EMOJI[i % NICHE_EMOJI.length]}
                    </span>
                    <div className="flex-1">
                      <p className="text-[13px] font-medium leading-snug">{niche.name}</p>
                      <p className="text-[11px] text-muted-foreground">{niche.angle}</p>
                    </div>
                    <span className="text-[11px] text-muted-foreground" aria-hidden>
                      →
                    </span>
                  </button>
                ))}
              </div>
            </section>
          </>
        )}

        <section className="rounded-[28px] bg-card p-4">
          <h2 className="font-round font-bold text-[17px] leading-tight">
            Redbubble Tag Generator — Best Redbubble Keywords Tool FAQ
          </h2>
          <p className="text-[12px] text-muted-foreground mt-1">
            Quick answers to help you rank higher with Redbubble tags and keywords.
          </p>
          <Accordion type="single" collapsible className="mt-2">
            {FAQ_DATA.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger className="text-[13px] font-round font-semibold py-3.5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-[12px] leading-relaxed text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>

        <p className="text-[10px] text-muted-foreground text-center leading-relaxed px-4">
          Suggestions are AI-generated — always verify against each platform's current tag &amp;
          trademark policies before publishing.
        </p>
      </div>
    </div>
  );
}

function LoadingCards() {
  return (
    <div className="space-y-4" aria-busy="true" aria-label="Generating suggestions">
      <section className="rounded-[28px] bg-card p-4">
        <div className="h-4 w-24 rounded-full bg-muted animate-pulse" />
        <div className="mt-3 flex flex-wrap gap-2">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className="h-7 rounded-full bg-muted animate-pulse"
              style={{ width: `${70 + ((i * 23) % 60)}px` }}
            />
          ))}
        </div>
      </section>
      <section className="rounded-[28px] bg-card p-4 space-y-2">
        <div className="h-4 w-20 rounded-full bg-muted animate-pulse" />
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="h-12 rounded-2xl bg-muted animate-pulse" />
        ))}
      </section>
    </div>
  );
}
