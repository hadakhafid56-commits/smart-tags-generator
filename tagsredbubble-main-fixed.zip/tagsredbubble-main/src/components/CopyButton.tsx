import { useState } from "react";

export function CopyButton({
  value,
  label = "Copy",
  tone = "coral",
  className = "",
}: {
  value: string;
  label?: string;
  tone?: "coral" | "plain";
  className?: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
    } catch {
      const el = document.createElement("textarea");
      el.value = value;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      el.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  }

  const tones =
    tone === "coral"
      ? "text-coral bg-coral-soft"
      : "text-muted-foreground bg-background";

  return (
    <button
      type="button"
      onClick={copy}
      aria-label={`${label}: ${value.slice(0, 40)}`}
      className={`shrink-0 rounded-full px-3 py-1.5 text-[11px] font-bold transition-transform active:scale-95 ${tones} ${className}`}
    >
      {copied ? "Copied!" : label}
    </button>
  );
}
