-- Roles infrastructure
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin','moderator','user');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;
CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;

-- Seed admin role for the creator account (if the account exists)
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role FROM auth.users WHERE lower(email) = 'moncefchaiibi14@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Unlimited generations for admins
CREATE OR REPLACE FUNCTION public.consume_generation_credit()
 RETURNS TABLE(allowed boolean, free_credits integer, is_subscribed boolean)
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  uid UUID := auth.uid();
  cur public.profiles;
  is_admin BOOLEAN;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  INSERT INTO public.profiles (id) VALUES (uid) ON CONFLICT (id) DO NOTHING;
  SELECT * INTO cur FROM public.profiles WHERE id = uid FOR UPDATE;

  SELECT public.has_role(uid, 'admin')
      OR EXISTS (SELECT 1 FROM auth.users u WHERE u.id = uid AND lower(u.email) = 'moncefchaiibi14@gmail.com')
    INTO is_admin;

  IF is_admin OR cur.is_subscribed THEN
    RETURN QUERY SELECT true, cur.free_credits, true;
  ELSIF cur.free_credits > 0 THEN
    UPDATE public.profiles p
      SET free_credits = p.free_credits - 1, updated_at = now()
      WHERE p.id = uid
      RETURNING p.free_credits INTO cur.free_credits;
    RETURN QUERY SELECT true, cur.free_credits, false;
  ELSE
    RETURN QUERY SELECT false, 0, false;
  END IF;
END;
$function$;

-- Report unlimited status for admins in the balance check
CREATE OR REPLACE FUNCTION public.ensure_profile()
RETURNS public.profiles LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  uid UUID := auth.uid();
  cur public.profiles;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  INSERT INTO public.profiles (id) VALUES (uid) ON CONFLICT (id) DO NOTHING;
  SELECT * INTO cur FROM public.profiles WHERE id = uid;
  IF public.has_role(uid, 'admin')
     OR EXISTS (SELECT 1 FROM auth.users u WHERE u.id = uid AND lower(u.email) = 'moncefchaiibi14@gmail.com') THEN
    cur.is_subscribed := true;
  END IF;
  RETURN cur;
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.ensure_profile() FROM anon;
REVOKE EXECUTE ON FUNCTION public.consume_generation_credit() FROM anon;