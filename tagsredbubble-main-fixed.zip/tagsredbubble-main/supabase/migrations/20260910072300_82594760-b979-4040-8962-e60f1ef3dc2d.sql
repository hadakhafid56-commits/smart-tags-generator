REVOKE EXECUTE ON FUNCTION public.ensure_profile() FROM anon;
REVOKE EXECUTE ON FUNCTION public.consume_generation_credit() FROM anon;