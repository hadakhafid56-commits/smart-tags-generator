CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY,
  email TEXT,
  free_credits INTEGER NOT NULL DEFAULT 5,
  is_subscribed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can create their own profile" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.ensure_profile()
RETURNS public.profiles
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid UUID := auth.uid();
  result public.profiles;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  INSERT INTO public.profiles (id) VALUES (uid) ON CONFLICT (id) DO NOTHING;
  SELECT * INTO result FROM public.profiles WHERE id = uid;
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION public.consume_generation_credit()
RETURNS TABLE (allowed BOOLEAN, free_credits INTEGER, is_subscribed BOOLEAN)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid UUID := auth.uid();
  cur public.profiles;
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  INSERT INTO public.profiles (id) VALUES (uid) ON CONFLICT (id) DO NOTHING;
  SELECT * INTO cur FROM public.profiles WHERE id = uid FOR UPDATE;

  IF cur.is_subscribed THEN
    RETURN QUERY SELECT true, cur.free_credits, true;
  ELSIF cur.free_credits > 0 THEN
    UPDATE public.profiles p
      SET free_credits = p.free_credits - 1, updated_at = now()
      WHERE p.id = uid
      RETURNING p.free_credits INTO cur.free_credits;
    RETURN QUERY SELECT true, cur.free_credits, false;
  ELSE
    RETURN QUERY SELECT false, 0, false;
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.ensure_profile() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.consume_generation_credit() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.ensure_profile() TO authenticated;
GRANT EXECUTE ON FUNCTION public.consume_generation_credit() TO authenticated, service_role;