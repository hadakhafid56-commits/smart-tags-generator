CREATE OR REPLACE FUNCTION public.protect_profile_sensitive_fields()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Allow privileged server-side roles to change credits/subscription.
  IF current_setting('role', true) IN ('service_role') OR auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;
  NEW.free_credits := OLD.free_credits;
  NEW.is_subscribed := OLD.is_subscribed;
  NEW.id := OLD.id;
  NEW.created_at := OLD.created_at;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS protect_profiles_sensitive_fields ON public.profiles;
CREATE TRIGGER protect_profiles_sensitive_fields
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.protect_profile_sensitive_fields();

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

REVOKE ALL ON FUNCTION public.protect_profile_sensitive_fields() FROM anon, authenticated;